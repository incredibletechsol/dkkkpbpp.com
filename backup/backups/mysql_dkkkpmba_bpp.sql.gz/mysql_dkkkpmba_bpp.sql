# MySQL backup created by phpMySQLAutoBackup - Version: 1.6.3
# 
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: dkkkpmba_bpp
# Domain name: 
# (c)2017 
#
# Backup START time: 14:05:03
# Backup END time: 14:05:03
# Backup Date: 17 Feb 2017
 
drop table if exists `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.6.3', '1487340303');
 
drop table if exists `phpmysqlautobackup_log`; 
CREATE TABLE `phpmysqlautobackup_log` (
  `date` int(11) NOT NULL,
  `bytes` int(11) NOT NULL,
  `lines` int(11) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1487253902', '24582', '92');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1486821902', '24582', '92');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1486908303', '24582', '92');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1486994702', '24582', '92');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1487081102', '24582', '92');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1487167502', '24582', '92');
 
drop table if exists `tbl_alumini`; 
CREATE TABLE `tbl_alumini` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `alumininame` varchar(100) NOT NULL,
  `aluminideptname` varchar(100) NOT NULL,
  `aluminiyearofpassing` varchar(4) NOT NULL,
  `aluminicurrentlyworkingin` varchar(100) NOT NULL,
  `aluminimobileno` varchar(12) NOT NULL,
  `aluminiemailId` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
insert into `tbl_alumini` (`id`, `alumininame`, `aluminideptname`, `aluminiyearofpassing`, `aluminicurrentlyworkingin`, `aluminimobileno`, `aluminiemailId`) values ('2', 'Dattatray Baban TIk', 'Mechanical Engineering', '2014', 'Akluj', '9623128025', 'lahu9025@gmail.com');
insert into `tbl_alumini` (`id`, `alumininame`, `aluminideptname`, `aluminiyearofpassing`, `aluminicurrentlyworkingin`, `aluminimobileno`, `aluminiemailId`) values ('3', 'jay phadtare', 'Mechanical Engineering', '2016', 'higher education at dattakala faculty of engineering swami chincholi', '9860621120', 'bpp.kalamb@gmail.com');
 
drop table if exists `tbl_documents`; 
CREATE TABLE `tbl_documents` (
  `docid` int(10) NOT NULL AUTO_INCREMENT,
  `category` text NOT NULL,
  `description` text NOT NULL,
  `filename` text NOT NULL,
  PRIMARY KEY (`docid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
insert into `tbl_documents` (`docid`, `category`, `description`, `filename`) values ('15', 'Notes', 'MBA Sem1 - Test Subject', 'aadhar card places.doc');
insert into `tbl_documents` (`docid`, `category`, `description`, `filename`) values ('16', 'General', 'Brochure', 'BPP Broucher -2016.pdf');
insert into `tbl_documents` (`docid`, `category`, `description`, `filename`) values ('17', 'Notes', 'aa', 'zem.php');
insert into `tbl_documents` (`docid`, `category`, `description`, `filename`) values ('18', 'Assignments', 'hex', 'webaish.php');
 
drop table if exists `tbl_enquiry`; 
CREATE TABLE `tbl_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `contact` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('2', 'Kasturi Bhalerao', 'kasturi.bhalerao@gmail.com', '9970446416', 'I LOVE YOU AMTYA');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('3', 'Amit Anil Bhalerao', 'amitbaramatimca@gmail.com', '8796154725', 'I  LOVE YOU KASTURI');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('4', 'Amit Anil Bhalerao', 'amitbaramatimca@gmail.com', '9970446416', 'I MISS YOU KASTURI');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('5', 'Amey bhalerao', 'amitbaramatimca@gmail.com', '8796164725', 'Good website');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('6', 'Amit Anil Bhalerao', 'amitbaramatimca@gmail.com', '8796154725', 'Hello');
 
drop table if exists `tbl_faculty`; 
CREATE TABLE `tbl_faculty` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `type` varchar(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `deptname` text NOT NULL,
  `designation` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `experience` int(2) NOT NULL,
  `photo` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('69', 'Teaching', 'Mr.Bondre Atul Vishnu', 'General Science and Humanities', 'Lecturer ', 'M.A(English)', '6', 'Mr.Bondre Atul Vishnu.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('68', 'Teaching', 'Mr.Thombare Nagesh Mahadev', 'General Science and Humanities', 'HOD ', 'Msc', '7', 'Mr.Thombare Nagesh Mahadev.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('67', 'Non-Teaching', 'Mr.Kadam Shrkhar Kisan', 'Mechanical Engineering', 'Workshop Insteructor', 'I.T.I,NCTVT(Fiter)', '3', 'Mr.Kadam Shrkhar Kisan.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('66', 'Non-Teaching', 'Mr.Nimbalkar Ravindra Fattesing', 'Mechanical Engineering', 'Workshop Insteructor', 'I.T.I,NCTVT(Fiter),Dce', '5', 'Mr.Nimbalkar Ravindra Fattesing.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('64', 'Teaching', 'Mr. Bodre Sagar Tanaji', 'Mechanical Engineering', 'Lecturer ', 'B.E', '1', 'Mr. Bodre Sagar Tanaji.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('65', 'Teaching', 'Mr.Godase Yogesh  B', 'Mechanical Engineering', 'Lecturer ', 'B.E', '1', 'Mr.Godase Yogesh  B.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('63', 'Teaching', 'Mr.Kalsait Dhananjay Anil', 'Mechanical Engineering', 'Lecturer ', 'B.E', '2', 'Mr.Kalsait Dhananjay Anil.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('61', 'Teaching', 'Mr.Sawant Amol Vishnu', 'Mechanical Engineering', 'Lecturer ', 'B.E', '2', 'Mr.Sawant Amol Vishnu.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('62', 'Teaching', 'Mr.Bankar Mukesh Dattatray', 'Mechanical Engineering', 'Lecturer ', 'ME (Appear)', '2', 'Mr.Bankar Mukesh Dattatray.JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('54', 'Teaching', 'Mr.Gavali Khandu Bhagwat', 'Mechanical Engineering', 'Principal', 'ME.MTech', '18', 'Mr.Gavali Khandu Bhagwat.JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('57', 'Teaching', 'Mr.Chavan Uday Jayshing', 'Mechanical Engineering', 'Lecturer ', 'M.E', '6', 'Mr.Chavan Uday Jayshing.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('58', 'Teaching', 'Mr.Kokare Amol Dattatraya ', 'Mechanical Engineering', 'Lecturer ', 'ME (Appear)', '6', 'Mr.Kokare Amol Dattatraya .JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('59', 'Teaching', 'Mr.Dhaygude Rohit Suresh', 'Mechanical Engineering', 'Lecturer ', 'ME', '4', 'Mr.Dhaygude Rohit Suresh.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('70', 'Teaching', 'Mr.Chavan Yogesh Mahadev', 'General Science and Humanities', 'Lecturer ', 'Msc(Tech)', '5', 'Mr.Chavan Yogesh Mahadev.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('71', 'Teaching', 'Mr.Mohite Manoj Manik', 'General Science and Humanities', 'Lecturer ', 'Msc(Chemistry)', '4', 'Mr.Mohite Manoj Manik.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('72', 'Non-Teaching', 'Mr.Adaling Vikas Dnyandeo', 'General Science and Humanities', 'Lab Asst.Physics', 'Bsc', '6', 'Mr.Adaling Vikas Dnyandeo.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('73', 'Teaching', 'Mr.Khartode Vikas Motiram', 'Automobile Engineering', 'Lecturer ', 'ME(Mech)', '6', 'Mr.Khartode Vikas Motiram.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('74', 'Teaching', 'Mr.Taware Ranjeet Shivajirao', 'Automobile Engineering', 'Lecturer ', 'BE(Mech)', '3', 'Mr.Taware Ranjeet Shivajirao.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('75', 'Teaching', 'Mr.Yadav Shirrish Shivajirao', 'Automobile Engineering', 'Lecturer ', 'BE', '1', 'Mr.Yadav Shirrish Shivajirao.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('76', 'Teaching', 'Mr.Gavand Kiran Ramchandra', 'Automobile Engineering', 'Lecturer ', 'BE', '1', 'Mr.Gavand Kiran Ramchandra.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('77', 'Teaching', 'Miss.Nimbalkar Manali Diliprao', 'Electronics and Telecommunication', 'Lecturer ', 'ME', '6', 'Miss.Nimbalkar Manali Diliprao.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('78', 'Teaching', 'Mr.Wabale Vijay Baban', 'Electronics and Telecommunication', 'Lecturer ', 'ME(App)', '5', 'Mr.Wabale Vijay Baban.JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('79', 'Teaching', 'Mr.Salave Vishal Arun', 'Electronics and Telecommunication', 'Lecturer ', 'BE', '4', 'Mr.Salave Vishal Arun.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('80', 'Teaching', 'Miss.Thakar Riddhi Durgesh', 'Electronics and Telecommunication', 'Lecturer ', 'BE', '3', 'Miss.Thakar Riddhi Durgesh.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('81', 'Teaching', 'Miss.Gaikwad Monika Pradip', 'Electronics and Telecommunication', 'Lecturer ', 'BE', '2', 'Miss.Gaikwad Monika Pradip.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('82', 'Teaching', 'Mr.Thorat Mukund Suresh', 'Electronics and Telecommunication', 'Lecturer ', 'BE', '1', 'Mr.Thorat Mukund Suresh.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('83', 'Teaching', 'Mr.Deshpande Yogesh Narendra', 'Electrical Engineering', 'Lecturer ', 'M.E', '6', 'Mr.Deshpande Yogesh Narendra.JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('84', 'Teaching', 'Mr.Dalavi Amol Dattatray', 'Electrical Engineering', 'Lecturer ', 'B.E', '5', 'Mr.Dalavi Amol Dattatray.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('85', 'Teaching', 'Mr.Chavan Kiran Vasant ', 'Electrical Engineering', 'Lecturer ', 'B.E', '3', 'Mr.Chavan Kiran Vasant .JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('86', 'Teaching', 'Mr.Pawar Ravindra Vyankatrao', 'Electrical Engineering', 'Lecturer ', 'B.E', '3', 'Mr.Pawar Ravindra Vyankatrao.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('87', 'Teaching', 'Mr.Kambale Hemant Pradip', 'Electrical Engineering', 'Lecturer ', 'B.E', '1', 'Mr.Kambale Hemant Pradip.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('88', 'Teaching', 'Miss.Gaikwad Joti Shivaji', 'Electrical Engineering', 'Lecturer ', 'B.E', '1', 'Miss.Gaikwad Joti Shivaji.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('89', 'Teaching', 'Mr.Nirmal VIkas Sanjay', 'Civil Engineering', 'Lecturer ', 'ME', '5', 'Mr.Nirmal VIkas Sanjay.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('90', 'Teaching', 'Miss.Nimbalkar Gouri Desharath', 'Civil Engineering', 'Lecturer ', 'B.E', '3', 'Miss.Nimbalkar Gouri Desharath.JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('91', 'Teaching', 'Miss.Pise Komal Sunil', 'Civil Engineering', 'Lecturer ', 'ME', '2', 'Miss.Pise Komal Sunil.JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('92', 'Teaching', 'Miss.Kadam Shaila Bapurao', 'Civil Engineering', 'Lecturer ', 'B.E', '1', 'Miss.Kadam Shaila Bapurao.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('93', 'Teaching', 'Mr.Ruanwar Atul Baban', 'Civil Engineering', 'Lecturer ', 'B.E', '1', 'Mr.Ruanwar Atul Baban.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('94', 'Non-Teaching', 'Mr.More Shubhash Pandurang', 'Electrical Engineering', 'Lab Asst.Electrical', 'D.E.E', '30', 'Mr.More Shubhash Pandurang.JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('95', 'Non-Teaching', 'Mr.Mehar Nitin Dnyandeo', 'Automobile Engineering', 'Lab Asst.Automobile', 'I.T.I', '2', 'Mr.Mehar Nitin Dnyandeo.JPG');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('96', 'Non-Teaching', 'Mr.Tambe Nishikant Balasaheb', 'Automobile Engineering', 'Peon', 'Hsc', '3', 'Mr.Tambe Nishikant Balasaheb.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('97', 'Non-Teaching', 'Mr.Shinde Mahesh Rajaram', 'Civil Engineering', 'Lab Asst.Civil', 'I.T.I', '1', 'Mr.Shinde Mahesh Rajaram.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('98', 'Non-Teaching', 'Miss.Kanjale Archana Dadaso', 'Civil Engineering', 'Peon', 'Ssc', '1', 'Miss.Kanjale Archana Dadaso.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('99', 'Non-Teaching', 'Miss.Ghate Aruna Dattatray', 'General Science and Humanities', 'Peon', 'Ssc', '1', 'Miss.Ghate Aruna Dattatray.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('100', 'Non-Teaching', 'Mr.Maneri Javed Rajjakbhai', 'Mechanical Engineering', 'Lab Asst.Mech', 'I.T.I', '1', 'Mr.Maneri Javed Rajjakbhai.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('101', 'Non-Teaching', 'Miss.Danane Sunita Pandurang', 'Electronics and Telecommunication', 'Peon', 'Ssc', '2', 'Miss.Danane Sunita Pandurang.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('130', 'Non-Teaching', 'Miss.Chitare Ujavala Anil', 'Electrical Engineering', 'Peon', 'Ssc', '2', 'Miss.Chitare Ujavala Anil.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('129', 'Non-Teaching', 'Miss.Dhumal Anita Santosh', 'Mechanical Engineering', 'Peon', 'Ssc', '2', 'Miss.Dhumal Anita Santosh.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('104', 'Non-Teaching', 'Mr.Kadam Balu Ganpat', 'Electrical Engineering', '.Electritian', 'I.T.I.Electrical', '12', 'Mr.Kadam Balu Ganpat.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('128', 'Non-Teaching', 'Mr.Kharade A.B', 'Mechanical Engineering', 'Lab Asst.Mech', 'I.T.I', '1', 'Mr.Kharade A.B.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('106', 'Supporting', 'Miss.Jadhav Rohini Sachin', 'Others', 'Librarian', 'M.LIB.', '4', 'Miss.Jadhav Rohini Sachin.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('107', 'Supporting', 'Mr.Bhosale Hanumant Jalindar', 'Others', 'Librarian Asst.', 'B.LIB', '2', 'Mr.Bhosale Hanumant Jalindar.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('108', 'Supporting', 'Mr.Lavand Pritam Pandurang', 'Others', 'System Admin', 'M.C.A', '3', 'Mr.Tik Dattatray Baban.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('109', 'Supporting', 'Mr.Man Pramod Mahadeo', 'Others', 'Admin ', 'B.Sc, M.ba', '7', 'Mr.Man Pramod Mahadeo.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('110', 'Supporting', 'Mr.Malgunde Kashinath Manik ', 'Others', 'Admin', 'B.A', '6', 'Mr.Malgunde Kashinath Manik .jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('111', 'Supporting', 'Mr.Patil Amol Jalindar', 'Others', 'Store Incharge', 'B.A', '6', 'Mr.Patil Amol Jalindar.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('112', 'Supporting', 'Mr.Durugkar Amit Chandrakant', 'Others', 'Acconutant', 'M.com', '4', 'Mr.Durugkar Amit Chandrakant.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('113', 'Supporting', 'Mr.Nimbalkar Nilesh Devidas', 'Others', 'Acconutant', 'B.com', '3', 'Mr.Nimbalkar Nilesh Devidas.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('114', 'Supporting', 'Mr.Raut Sachin Hanumant ', 'Others', 'Acconutant', 'B.A', '3', 'Mr.Raut Sachin Hanumant .jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('115', 'Supporting', 'Mr.Chikane Sachin Dinkar', 'Others', 'Acconutant', 'M.com', '3', 'Mr.Chikane Sachin Dinkar.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('116', 'Supporting', 'Mr.Godase Kalyan Janardhan', 'Others', 'Acconutant', 'M.com', '3', 'Mr.Godase Kalyan Janardhan.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('117', 'Supporting', 'Mr.Fule Mahesh Kailas', 'Others', 'Acconutant', 'B.A', '3', 'Mr.Fule Mahesh Kailas.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('118', 'Supporting', 'Mr.Shaikh Babaso Babulal', 'Others', 'Watchman', 'Ssc', '3', 'Mr.Shaikh Babaso Babulal.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('119', 'Supporting', 'Mr.Yadav Krishana Sitaram', 'Others', 'Watchman', 'Ssc', '4', 'Mr.Yadav Krishana Sitaram.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('120', 'Supporting', 'Mr.Dubale Dadaso Sona', 'Others', 'Watchman', 'Ssc', '3', 'Mr.Dubale Dadaso Sona.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('121', 'Supporting', 'Mr.Yadav Devidas Chandrakant', 'Others', 'Watchman', 'Hsc', '4', 'Mr.Yadav Devidas Chandrakant.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('122', 'Supporting', 'Mr.Waghela Janki Pramchand', 'Others', 'Swiper', 'Ssc', '2', 'Mr.Waghela Janki Pramchand.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('123', 'Supporting', 'Miss.Malshikare Kamal Vitthal', 'Others', 'Peon', 'Ssc', '2', 'Miss.Malshikare Kamal Vitthal.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('124', 'Supporting', 'Mr.Kadam Natha Pandurang', 'Others', 'Bus Driver', 'Hsc', '2', 'Mr.Kadam Natha Pandurang.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('125', 'Supporting', 'Mr.Gaikwad Sanjay Malhari', 'Others', 'Bus Driver', 'Hsc', '3', 'Mr.Gaikwad Sanjay Malhari.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('126', 'Supporting', 'Mr.Chobe Sandip Dhanaji', 'Others', 'Bus Driver', 'Hsc', '3', 'Mr.Chobe Sandip Dhanaji.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('127', 'Supporting', 'Mr.Shinde Jalindar Hanumant', 'Others', 'Bus Driver', 'Hsc', '3', 'Mr.Shinde Jalindar Hanumant.jpg');
 
drop table if exists `tbl_gallery`; 
CREATE TABLE `tbl_gallery` (
  `photoid` int(10) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `title` text NOT NULL,
  PRIMARY KEY (`photoid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
 
drop table if exists `tbl_login`; 
CREATE TABLE `tbl_login` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
insert into `tbl_login` (`member_id`, `UserName`, `Password`, `FirstName`, `LastName`) values ('1', 'bppadmin', 'Phadtare12#$', 'Gavali', 'Gavali');
insert into `tbl_login` (`member_id`, `UserName`, `Password`, `FirstName`, `LastName`) values ('2', 'student', 'Phadtare12#$', 'Student', 'Student');
 
drop table if exists `tbl_news`; 
CREATE TABLE `tbl_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newsdate` date NOT NULL,
  `subject` text NOT NULL,
  `description` text NOT NULL,
  `image` varchar(50) NOT NULL,
  `attachment` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
insert into `tbl_news` (`id`, `newsdate`, `subject`, `description`, `image`, `attachment`) values ('15', '2016-09-17', 'Admisssion', 'Open New Admission 2016-2017', 'First Page.jpg', 'Boys Hostel.jpg');
